<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Logisk fejl</title>
</head>
<body>
<?php
function average($a, $b) {
  return $a + $b / 2;
}
echo(average(4, 11));
?>
</body>
</html>
