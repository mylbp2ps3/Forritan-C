<?php
$day;
$month;
$year;

/* Ændrer datoen til næste dag */
function setToNextDate() {

}

/* Viser datoen i formatet dd-mm-åååå */
function showDate() {
	echo "";
}
?>
